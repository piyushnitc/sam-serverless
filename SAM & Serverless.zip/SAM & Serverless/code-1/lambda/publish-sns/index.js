'use strict';

var aws = require('aws-sdk');
aws.config.update({region: 'us-east-1'});

var dynamodb = new aws.DynamoDB();
var sns = new aws.SNS();

exports.handler = (event, context, callback) => {
    event.Records.forEach(function(record) {
    const id = record.dynamodb.NewImage.id.N;

    // example key: image-XXX.png
    //const dotIndex = key.lastIndexOf(".");
    //const id = key.substring(6, dotIndex);

    const params = {
      Message: `Data with ID '${id}' was succesfully inserted`,
      TopicArn: process.env.SNSTopicARN
    };

    sns.publish(params, function(err, data) {
      callback(null, '');
    });
  });
}
